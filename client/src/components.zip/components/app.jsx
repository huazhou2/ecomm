import React, {Component} from 'react';
import data from '../data/massagedata.json'
import Header from './header.jsx';

class App extends Component {

  render() {
	      return (
		      <Header data={data}/>
    )
  }
}

export default App;
