import React,{Component} from 'react';
import {withRouter} from 'react-router';

class Test extends Component{
	constructor(props) {
		super(props);
		this.state={id:this.props.id};
	}
	render() {
		return(
		<React.Fragment>
			<h2> this is test {this.props.match.url}</h2>
		</React.Fragment>
		)
	}
}
export default Test;
